Setup:
	- copy "obs-plugins" directory into your OBS-Studio installation path
	- in OBS-Studio choose "Tools"->"Heroes Scene Switch" to configure the plugin

	- two gamestates are possible - "Menu" and "Game"
	- "Game" state is triggerd when a savegame is created ( ~1 minute delayed :/ )
	- "Menu" state is triggerd when a replay is created
	  - auto save replays should be enabled in Heroes